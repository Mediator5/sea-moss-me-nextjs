import Link from "next/link";
import { site } from "@/lib/site";
import { products } from "@/lib/products";
import { NewsletterForm } from "./newsletter-form";
import { Wordmark } from "./wordmark";

const columns = [
  {
    title: "Shop",
    links: [
      { label: "All flavours", href: "/products" },
      ...products.map((p) => ({ label: p.name, href: `/products/${p.slug}` })),
    ],
  },
  {
    title: "Learn",
    links: [
      { label: "Sea Moss 101", href: "/sea-moss" },
      { label: "Nature's Wisdom", href: "/natures-wisdom" },
      { label: "Our story", href: "/about" },
      { label: "How it's made", href: "/about#process" },
      { label: "Journal", href: "/blog" },
      { label: "FAQ", href: "/faq" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Contact us", href: "/contact" },
      { label: "Shipping & delivery", href: "/faq#shipping" },
      { label: "Privacy policy", href: "/privacy" },
      { label: "Terms of service", href: "/terms" },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer className="relative overflow-hidden bg-lagoon-500 text-abyss-950">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 -right-32 size-[32rem] rounded-full bg-white/12 blur-3xl"
      />

      <div className="container-page relative py-20">
        <div className="grid gap-14 lg:grid-cols-[1.15fr_2fr]">
          <div className="max-w-sm">
            <Wordmark className="h-12" />
            <p className="mt-6 text-sm leading-relaxed text-abyss-950/90">{site.description}</p>
            <div className="mt-8 space-y-1.5 text-sm">
              <a href={`mailto:${site.email}`} className="link-underline block text-abyss-950/90">
                {site.email}
              </a>
              <a href={`tel:${site.phoneHref}`} className="link-underline block text-abyss-950/90">
                {site.phone}
              </a>
              <p className="text-abyss-950/90">{site.address}</p>
            </div>
          </div>

          <div className="grid gap-10 sm:grid-cols-3">
            {columns.map((col) => (
              <div key={col.title}>
                <h3 className="eyebrow font-sans text-flame-800">{col.title}</h3>
                <ul className="mt-5 space-y-2.5">
                  {col.links.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="link-underline text-sm text-abyss-950/90 hover:text-abyss-950"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 grid gap-8 rounded-lg border border-abyss-950/15 bg-white/35 p-8 md:grid-cols-2 md:items-center">
          <div>
            <h3 className="font-display text-2xl text-abyss-950">Join the Sea Moss Me list</h3>
            <p className="mt-2 text-sm text-abyss-950/90">
              New batches, restock alerts and the odd recipe. No noise, unsubscribe any time.
            </p>
          </div>
          <NewsletterForm />
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-abyss-950/15 pt-8 text-xs text-abyss-950/90 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} {site.name}. All rights reserved.
          </p>
          <p className="max-w-xl leading-relaxed">
            These statements have not been evaluated by the Food and Drug Administration. This
            product is not intended to diagnose, treat, cure or prevent any disease.
          </p>
        </div>
      </div>
    </footer>
  );
}
